"""/////////////////////////
///
///   File: TEXTASSET/TEXTSPRITE/__init__.py
///   Author: Anicet Nougaret
///   License: CC BY-SA (see FLORE1/license.txt)
///
/////////////////////////"""

from .textSprite import *
