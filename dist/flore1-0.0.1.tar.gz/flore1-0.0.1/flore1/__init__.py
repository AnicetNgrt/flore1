"""/////////////////////////
///
///   File: __init__.py
///   Author: Anicet Nougaret
///   License: CC BY-SA (see FLORE1/license.txt)
///
/////////////////////////"""

name = "flore1"

from .flore1 import *
