"""/////////////////////////
///
///   File: TEXTASSET/__init__.py
///   Author: Anicet Nougaret
///   License: CC BY-SA (see FLORE1/license.txt)
///
/////////////////////////"""

from .textAsset import *
