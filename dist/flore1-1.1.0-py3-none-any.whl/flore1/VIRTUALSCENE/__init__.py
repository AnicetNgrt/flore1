"""/////////////////////////
///
///   File: VIRTUALSCENE/__init__.py
///   Author: Anicet Nougaret
///   License: CC BY-SA (see FLORE1/license.txt)
///
/////////////////////////"""

from .virtualScene import *
